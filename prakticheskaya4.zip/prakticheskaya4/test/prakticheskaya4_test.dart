import 'package:prakticheskaya4/prakticheskaya4.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
